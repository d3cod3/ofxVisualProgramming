/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx.h"
#include "../common/t3bv_32.c"
